//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicShellLib.rc
//
#define IDS_VERSION_URL                 100
#define IDI_CLASSICSHELL                102
#define IDC_STATICICON                  209
#define IDC_SETTINGS                    236
#define IDC_TREEITEMS                   238
#define IDC_COMBOCOMMAND                239
#define IDC_EDITLABEL                   240
#define IDC_EDITTIP                     241
#define IDC_BUTTONLINK                  242
#define IDC_EDITLINK                    244
#define IDC_EDITICON                    245
#define IDC_BUTTONICON                  246
#define IDC_EDITICOND                   247
#define IDC_BUTTONICOND                 248
#define IDC_TABSETTINGS                 250
#define IDC_STATICCOMMAND               251
#define IDC_STATICLINK                  252
#define IDC_STATICTEXT                  253
#define IDC_STATICINFOTIP               254
#define IDC_STATICICOND                 255
#define IDC_ICONN                       256
#define IDC_ICOND                       257
#define IDC_COMBOLINK                   258
#define IDC_STATICHINT                  259
#define IDI_ICONLOCK                    1000
#define IDI_ICONWARNING                 1001
#define IDI_ICONPLAY                    1002
#define IDC_EDITFILE                    1001
#define IDC_BUTTONBROWSE                1002
#define IDC_LISTICONS                   1003
#define IDC_LISTLANGUAGE                1004
#define IDC_STATICTIP                   1005
#define IDC_TREE1                       1006
#define IDC_TREECOMMANDS                1006
#define IDC_STATICLEFT                  1007
#define IDC_STATICRIGHT                 1008
#define IDC_STATICMIDDLE                1009
#define IDC_LINKHELP                    1010
#define IDC_BUTTONBACKUP                1011
#define IDC_RADIOBASIC                  1012
#define IDC_RADIOALL                    1013
#define IDC_STATICFILE                  1013
#define IDD_SETTINGS                    4000
#define IDS_TOGGLE_SETTING              4000
#define IDD_SETTINGSTREE                4001
#define IDS_SELECT_SETTING              4001
#define IDD_BROWSEFORICON               4002
#define IDS_DEFAULT_SETTING             4002
#define IDD_LANGUAGE                    4003
#define IDS_PLAY_SETTING                4003
#define IDD_CUSTOMTREE                  4004
#define IDS_ICON_FILTERS                4004
#define IDS_ICON_TITLE                  4005
#define IDS_WAV_FILTERS                 4006
#define IDS_WAV_TITLE                   4007
#define IDS_SETTING_LOCKED              4008
#define IDS_SETTING_LOCKED_GP           4009
#define IDS_BASIC_SETTINGS              4010
#define IDS_ALWAYS_ON_TOP               4011
#define IDS_MENU_EDIT                   4012
#define IDS_MENU_DELETE                 4013
#define IDS_MENU_RENAME                 4014
#define IDS_PICK_LINK_TITLE             4015
#define IDS_PICK_LINK_FILE              4016
#define IDS_PICK_LINK_FOLDER            4017
#define IDS_DUPLICATE_ITEM              4018
#define IDS_ERROR_TITLE                 4019
#define IDS_ERROR_SEPARATOR             4020
#define IDS_ERROR_ASCII                 4021
#define IDS_ERROR_EMPTY                 4022
#define IDS_RESET_TOOLBAR               4023
#define IDS_RESET_TOOLBAR_WARN          4024
#define IDS_RESET_MENU                  4025
#define IDS_RESET_MENU_WARN             4026
#define IDS_ADD_TOOLBAR                 4027
#define IDS_ADD_MENU                    4028
#define IDS_INSERT_MENU                 4029
#define IDS_EMPTY_MENU                  4030
#define IDS_TREE_TOOLBAR                4031
#define IDS_TREE_MENU                   4032
#define IDS_XML_FILTERS                 4033
#define IDS_XML_TITLE_LOAD              4034
#define IDS_XML_TITLE_SAVE              4035
#define IDS_RESET_CONFIRM               4036
#define IDS_RESET_TITLE                 4037
#define IDS_TOOLBAR_LOCKED              4038
#define IDS_MENU_LOCKED                 4039
#define IDS_BACKUP_SAVE                 4040
#define IDS_BACKUP_LOAD                 4041
#define IDS_BACKUP_RESET                4042
#define IDS_ERROR_LOADING_XML           4043
#define IDS_ERROR_SAVING_XML            4044
#define IDS_DRAG_DROP_EXP_TIP           4045
#define IDS_DRAG_DROP_SM_TIP            4046
#define IDS_COMMAND_EXP_TIP             4047
#define IDS_STRING4048                  4048
#define IDS_COMMAND_SM_TIP              4048
#define IDS_COMMAND_FILTERS             4049
#define IDS_OS_LANGUAGE                 4050
#define IDS_BMP_FILTERS                 4051
#define IDS_BMP_TITLE                   4052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
