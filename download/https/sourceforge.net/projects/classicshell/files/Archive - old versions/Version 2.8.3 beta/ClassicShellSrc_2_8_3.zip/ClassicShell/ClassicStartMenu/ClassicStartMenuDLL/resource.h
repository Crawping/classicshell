//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicStartMenuDLL.rc
//
#define IDD_RENAME                      102
#define IDC_EDITNAME                    102
#define IDD_RENAMER                     103
#define IDI_APPICON                     103
#define IDD_LOGOFF                      104
#define IDD_LOGOFFR                     105
#define IDC_CHECKLOGOFF                 1001
#define IDC_CHECKFAVORITES              1002
#define IDC_CHECKUNDOCK                 1003
#define IDC_CHECKRECENT                 1004
#define IDC_CHECKCONTROLPANEL           1005
#define IDC_CHECKPRINTERS               1006
#define IDC_CHECKNETWORK                1007
#define IDC_LINKHELP                    1010
#define IDC_CHECKDOCUMENTS              1011
#define IDC_LINKINI                     1012
#define IDC_STATICICON                  1014
#define IDC_PROMPT                      1015
#define IDC_HOTKEY                      1017
#define IDC_CHECKLINKS                  1018
#define IDC_COMBOSKIN                   1019
#define IDC_ABOUT                       1020
#define IDB_ARROWS                      1020
#define IDC_COMBOVAR                    1021
#define IDC_STATICVAR                   1022
#define IDC_STATICOPT                   1023
#define IDC_LISTOPTIONS                 1024
#define IDC_STATICVER                   1025
#define IDC_HOTKEYW                     1026
#define IDC_COMBOSKIN2                  1027
#define IDC_COMBOCLICK                  1036
#define IDC_SHIELD                      1037
#define IDC_COMBOSWIN                   1038
#define IDC_COMBOSCLICK                 1039
#define IDC_COMBOWIN                    1040
#define IDC_CHECKERRORS                 1041
#define IDC_COMBOMCLICK                 1042
#define IDC_COMBOSCROLL                 1043
#define IDC_CHECKEXPANDPROGRAMS         1044
#define IDC_COMBOHOVER                  1045
#define IDC_STATICSKIN2                 1046
#define IDC_LABEL                       1047
#define IDC_RADIOSEARCH                 1048
#define IDC_RADIO2                      1049
#define IDC_RADIOALL                    1049
#define IDC_STATICFOCUS                 1050
#define IDD_SETTINGS                    3001
#define IDS_APP_TITLE                   3001
#define IDS_SETTINGS_TITLE              3002
#define IDS_SETTINGS_TITLE_VER          3003
#define IDS_SCROLL_NO                   3004
#define IDS_SCROLL_YES                  3005
#define IDS_SCROLL_AUTO                 3006
#define IDS_CTRL_NOTHING                3007
#define IDS_CTRL_CLASSIC                3008
#define IDS_CTRL_WINDOWS                3009
#define IDS_INI_WARNING                 3010
#define IDS_INI_IGNORE                  3011
#define IDS_SKIN_ERR_UNKNOWN            3012
#define IDS_SKIN_ERR_DISABLE            3013
#define IDS_SKIN_ERR                    3014
#define IDS_SKIN_WARN                   3015
#define IDS_SKIN_ABOUT                  3016
#define IDS_SKIN_FAIL                   3017
#define IDS_SKIN_ERR_BMPRES             3018
#define IDS_SKIN_ERR_BMPFILE            3019
#define IDS_SKIN_ERR_MASKRES            3020
#define IDS_SKIN_ERR_MASKFILE           3021
#define IDS_SKIN_ERR_MASKSIZE           3022
#define IDS_SKIN_ERR_FIND_RES1          3023
#define IDS_SKIN_ERR_LOAD_RES1          3024
#define IDS_SKIN_ERR_LOAD_FILE1         3025
#define IDS_SKIN_ERR_FIND_RES           3026
#define IDS_SKIN_ERR_LOAD_RES           3027
#define IDS_SKIN_ERR_LOAD_FILE          3028
#define IDS_SKIN_ERR_LOAD               3029
#define IDS_SKIN_ERR_VERSION            3030
#define IDS_MENU_TITLE                  3031
#define IDS_MAIN_SKIN                   3032
#define IDS_DEFAULT_SKIN                3033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
