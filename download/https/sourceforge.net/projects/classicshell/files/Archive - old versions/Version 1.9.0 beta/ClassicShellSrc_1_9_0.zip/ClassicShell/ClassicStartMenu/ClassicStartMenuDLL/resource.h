//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicStartMenuDLL.rc
//
#define IDD_SETTINGS                    101
#define IDD_RENAME                      102
#define IDC_EDITNAME                    102
#define IDD_RENAME1                     103
#define IDD_RENAMER                     103
#define IDI_ICON1                       103
#define IDI_APPICON                     103
#define IDD_LOGOFF                      104
#define IDD_LOGOFFR                     105
#define IDB_BITMAP1                     106
#define IDC_CHECKLOGOFF                 1001
#define IDC_CHECKFAVORITES              1002
#define IDC_CHECKUNDOCK                 1003
#define IDC_CHECKSMALL                  1004
#define IDC_CHECKCONTROLPANEL           1005
#define IDC_CHECKPRINTERS               1006
#define IDC_CHECKNETWORK                1007
#define IDC_CHECKSCROLL                 1008
#define IDC_EDITRECENT                  1009
#define IDC_LINKHELP                    1010
#define IDC_CHECKDOCUMENTS              1011
#define IDC_CHECKTHEME                  1012
#define IDC_LINKHELP2                   1012
#define IDC_LINKINI                     1012
#define IDC_CHECKCONFIRM                1013
#define IDC_STATICICON                  1014
#define IDC_PROMPT                      1015
#define IDC_CHECKHOTKEY                 1016
#define IDC_HOTKEY                      1017
#define IDC_CHECKLINKS                  1018
#define IDC_COMBOSKIN                   1019
#define IDC_BUTTON1                     1020
#define IDC_ABOUT                       1020
#define IDB_ARROWS                      1020
#define IDC_COMBOVAR                    1021
#define IDC_STATICVAR                   1022
#define IDC_CHECK1                      1023
#define IDC_CHECKSHIFT                  1023
#define IDC_STATICOPT                   1023
#define IDC_LISTOPTIONS                 1024
#define IDC_STATICVER                   1025
#define IDC_HOTKEYW                     1026
#define IDC_COMBOCLICK                  1036
#define IDC_SHIELD                      1037
#define IDC_COMBOSWIN                   1038
#define IDC_COMBOSCLICK                 1039
#define IDC_COMBOWIN                    1040
#define IDC_LABEL                       65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
