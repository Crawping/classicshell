//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicExplorer.rc
//
#define IDI_APPICON                     1
#define IDI_UP                          2
#define IDI_UPDISABLED                  3
#define IDI_UP2NORMAL                   4
#define IDI_UP2PRESSED                  5
#define IDI_UP2HOT                      6
#define IDI_UP2DISABLED                 7
#define IDS_PROJNAME                    100
#define IDR_CLASSICEXPLORER             101
#define IDR_EXPLORERBAND                102
#define IDR_EXPLORERBHO                 104
#define IDD_FILEMULTI                   129
#define IDD_FILE                        130
#define IDC_LINKMORE                    204
#define IDC_CHECKBHO                    205
#define IDC_CHECKCOPY                   206
#define IDD_SETTINGS                    207
#define IDC_STATICPROMPT1               207
#define IDC_CHECKBIG                    207
#define IDC_STATICPROMPT2               208
#define IDD_FILEMULTIR                  208
#define IDC_STATICICON                  209
#define IDD_FILER                       209
#define IDC_CHECK1                      210
#define IDD_FOLDERMULTI                 210
#define IDC_CHECK2                      211
#define IDD_FILE1                       211
#define IDD_FOLDER                      211
#define IDC_CHECK3                      212
#define IDD_FOLDERR                     212
#define IDC_CHECK4                      213
#define IDD_FOLDERMULTI1                213
#define IDD_FOLDERMULTIR                213
#define IDC_CHECK5                      214
#define IDC_CHECK6                      215
#define IDR_REGISTRY1                   216
#define IDR_CLASSICCOPYEXT              216
#define IDC_CHECKXPSTYLE                216
#define IDC_CHECKSIMPLE                 217
#define IDC_CHECKNOFADE                 218
#define IDC_CHECKSIZE                   219
#define IDC_CHECKSIZEEMPTY              220
#define IDC_CHECKAUTO                   220
#define IDC_CHECKCOPYFOLDER             221
#define IDC_CHECK7                      222
#define IDC_CHECK8                      223
#define IDC_COMBOSTYLE                  224
#define IDC_CHECKOFFSET                 225
#define IDC_CHECKUP                     226
#define IDC_CHECKPATH                   227
#define IDC_CHECKTITLE                  227
#define IDC_CHECKICON                   228
#define IDC_CHECKCRUMBS                 229
#define IDC_STATICFNAME                 1003
#define IDC_STATICSRCSIZE               1004
#define IDC_STATICSRCTIME               1005
#define IDC_STATICDSTSIZE               1006
#define IDC_STATICDSTTIME               1007
#define IDC_STATICSRCICON               1008
#define IDC_STATICDSTICON               1009
#define IDC_LINKHELP                    1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        224
#define _APS_NEXT_COMMAND_VALUE         32769
#define _APS_NEXT_CONTROL_VALUE         230
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
