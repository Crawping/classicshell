//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ClassicStartMenuDLL.rc
//
#define IDD_SETTINGS                    101
#define IDD_RENAME                      102
#define IDC_EDITNAME                    102
#define IDD_RENAME1                     103
#define IDD_RENAMER                     103
#define IDI_ICON1                       103
#define IDI_APPICON                     103
#define IDC_CHECKLOGOFF                 1001
#define IDC_CHECKFAVORITES              1002
#define IDC_CHECKUNDOCK                 1003
#define IDC_CHECKSMALL                  1004
#define IDC_CHECKCONTROLPANEL           1005
#define IDC_CHECKPRINTERS               1006
#define IDC_CHECKNETWORK                1007
#define IDC_CHECKSCROLL                 1008
#define IDC_EDITRECENT                  1009
#define IDC_LINKHELP                    1010
#define IDC_CHECKDOCUMENTS              1011
#define IDC_CHECKTHEME                  1012
#define IDC_LABEL                       65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
