#include <windows.h>

extern "C" BOOL WINAPI DllMain( HINSTANCE, DWORD, LPVOID )
{
	return TRUE;
}
